# 50.041 Distributed Systems Problem Set 1

**Name**: Ryan Toh
**Student ID**: 1005129

The respective READMEs for each question are stored in their respective directories:
- [Question 1 (Clocks)](./q1/README.md)
- [Question 2 (Bully Algorithm)](./q2/README.md)
