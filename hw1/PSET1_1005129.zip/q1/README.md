# PSET1 Question 1

**Name**: Ryan Toh
**Student ID**: 1005129

The respective READMEs for each separate part are stored in their respective directories:
- [Part 1 (Simulated Client-Server)](./part1/README.md)
- [Part 2 (Lamport Clocks)](./part2/README.md)
- [Part 3 (Vector Clocks)](./part3/README.md)
