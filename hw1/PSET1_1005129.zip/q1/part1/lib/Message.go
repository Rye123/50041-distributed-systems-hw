package lib

type Message struct {
	SrcId int
	Data  string
}
